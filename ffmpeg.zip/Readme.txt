You can just copy ffmpeg.exe to you FFmpeg Batch AV Converter application path.
Or you can extract it to a different folder and locate it on application startup.

NOTE: This is the full version of ffmpeg. Other development releases available at:
https://www.gyan.dev/ffmpeg/builds/
